<?php
    session_start();
    error_reporting(0);

    if ($_SESSION['user']) {
        header('Location: vendor/admin.php');
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Индекс</title>
    </head>
    <body>
     <div class="modal-body">
         <form action="vendor/signip.php" action="" method="post">
             <H3>Войти</h3>
             <label>Ваш логин</label>
             <input type="text" name="login" placeholder="Логин"><br/>
             <label>Пароль</label>
             <input type="text" name="password" placeholder="Пароль"><br/>
             <button id="Btn">Отправить</button>
             <?php
             if (@$_SESSION['message']) {
                 echo '<p class="msg"> ' . @$_SESSION['message'] . ' </p>';
             }
             unset($_SESSION['message']);
             ?>
         </form>
     </div>
    </body>
</html>
